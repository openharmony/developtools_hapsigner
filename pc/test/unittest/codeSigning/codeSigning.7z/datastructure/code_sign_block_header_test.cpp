﻿/*
 * Copyright (c) 2021-2023 Huawei Device Co., Ltd.
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *     http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
 
#include <memory>
#include <gtest/gtest.h>
#include "code_sign_block_header.h"

using namespace OHOS::SignatureTools;

 /*
 * 测试套件,固定写法
 */
class CodeSignBlockHeaderTest : public testing::Test
{
public:
    static void SetUpTestCase(void) {};
    static void TearDownTestCase() {};
    void SetUp() {};
    void TearDown() {};
};

/**
 * @tc.name: fromByteArray
 * @tc.desc: Test function of SignToolServiceImpl::GenerateCsr() interface for SUCCESS.
 * @tc.size: MEDIUM
 * @tc.type: FUNC
 * @tc.level Level 1
 * @tc.require: SR000H63TL
 */
HWTEST_F(CodeSignBlockHeaderTest, fromByteArray, testing::ext::TestSize.Level1)
{
    std::shared_ptr<CodeSignBlockHeader> api(new CodeSignBlockHeader());

    std::vector<signed char> bytes;
    CodeSignBlockHeader* codeSignBlockHeader = api->fromByteArray(bytes);

    EXPECT_NE(codeSignBlockHeader, nullptr);
}

/**
 * @tc.name: getBlockSize
 * @tc.desc: Test function of SignToolServiceImpl::GenerateCsr() interface for SUCCESS.
 * @tc.size: MEDIUM
 * @tc.type: FUNC
 * @tc.level Level 1
 * @tc.require: SR000H63TL
 */
HWTEST_F(CodeSignBlockHeaderTest, getBlockSize, testing::ext::TestSize.Level1)
{
    std::shared_ptr<CodeSignBlockHeader> api(new CodeSignBlockHeader());
    
    int blockSize = api->getBlockSize();

    EXPECT_EQ(blockSize, 0);
}

/**
 * @tc.name: getSegmentNum
 * @tc.desc: Test function of SignToolServiceImpl::GenerateCsr() interface for SUCCESS.
 * @tc.size: MEDIUM
 * @tc.type: FUNC
 * @tc.level Level 1
 * @tc.require: SR000H63TL
 */
HWTEST_F(CodeSignBlockHeaderTest, getSegmentNum, testing::ext::TestSize.Level1)
{
    std::shared_ptr<CodeSignBlockHeader> api(new CodeSignBlockHeader());

    int SegmentNum = api->getSegmentNum();

    EXPECT_EQ(SegmentNum, 0);
}

/**
 * @tc.name: setBlockSize
 * @tc.desc: Test function of SignToolServiceImpl::GenerateCsr() interface for SUCCESS.
 * @tc.size: MEDIUM
 * @tc.type: FUNC
 * @tc.level Level 1
 * @tc.require: SR000H63TL
 */
HWTEST_F(CodeSignBlockHeaderTest, setBlockSize, testing::ext::TestSize.Level1)
{
    std::shared_ptr<CodeSignBlockHeader> api(new CodeSignBlockHeader());

    api->setBlockSize(1024);

    EXPECT_EQ(true, 1);
}

/**
 * @tc.name: setFlags
 * @tc.desc: Test function of SignToolServiceImpl::GenerateCsr() interface for SUCCESS.
 * @tc.size: MEDIUM
 * @tc.type: FUNC
 * @tc.level Level 1
 * @tc.require: SR000H63TL
 */
HWTEST_F(CodeSignBlockHeaderTest, setFlags, testing::ext::TestSize.Level1)
{
    std::shared_ptr<CodeSignBlockHeader> api(new CodeSignBlockHeader());

    api->setFlags(1);

    EXPECT_EQ(true, 1);
}

/**
 * @tc.name: setSegmentNum
 * @tc.desc: Test function of SignToolServiceImpl::GenerateCsr() interface for SUCCESS.
 * @tc.size: MEDIUM
 * @tc.type: FUNC
 * @tc.level Level 1
 * @tc.require: SR000H63TL
 */
HWTEST_F(CodeSignBlockHeaderTest, setSegmentNum, testing::ext::TestSize.Level1)
{
    std::shared_ptr<CodeSignBlockHeader> api(new CodeSignBlockHeader());

    api->setSegmentNum(4);

    EXPECT_EQ(true, 1);
}

/**
 * @tc.name: size
 * @tc.desc: Test function of SignToolServiceImpl::GenerateCsr() interface for SUCCESS.
 * @tc.size: MEDIUM
 * @tc.type: FUNC
 * @tc.level Level 1
 * @tc.require: SR000H63TL
 */
HWTEST_F(CodeSignBlockHeaderTest, size, testing::ext::TestSize.Level1)
{
    std::shared_ptr<CodeSignBlockHeader> api(new CodeSignBlockHeader());

    int headerSize = api->size();

    EXPECT_EQ(headerSize, 0);
}

/**
 * @tc.name: toByteArray
 * @tc.desc: Test function of SignToolServiceImpl::GenerateCsr() interface for SUCCESS.
 * @tc.size: MEDIUM
 * @tc.type: FUNC
 * @tc.level Level 1
 * @tc.require: SR000H63TL
 */
HWTEST_F(CodeSignBlockHeaderTest, toByteArray, testing::ext::TestSize.Level1)
{
    std::shared_ptr<CodeSignBlockHeader> api(new CodeSignBlockHeader());

    std::vector<int8_t> byteArray = api->toByteArray();

    EXPECT_EQ(byteArray.size(), 0);
}

/**
 * @tc.name: toString
 * @tc.desc: Test function of SignToolServiceImpl::GenerateCsr() interface for SUCCESS.
 * @tc.size: MEDIUM
 * @tc.type: FUNC
 * @tc.level Level 1
 * @tc.require: SR000H63TL
 */
HWTEST_F(CodeSignBlockHeaderTest, toString, testing::ext::TestSize.Level1)
{
    std::shared_ptr<CodeSignBlockHeader> api(new CodeSignBlockHeader());

    std::string str = api->toString();

    EXPECT_EQ(str.size(), 0);
}
