/*
 * Copyright (c) 2021-2023 Huawei Device Co., Ltd.
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *     http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */

#include <memory>
#include <gtest/gtest.h>
#include "hap_info_segment.h"

using namespace OHOS::SignatureTools;

/*
* �����׼�,�̶�д��
*/
class HapInfoSegmentTest : public testing::Test
{
public:
    static void SetUpTestCase(void) {};
    static void TearDownTestCase() {};
    void SetUp() {};
    void TearDown() {};
};

// /**
//  * @tc.name: fromByteArray
//  * @tc.desc: Test function of SignToolServiceImpl::GenerateCsr() interface for SUCCESS.
//  * @tc.size: MEDIUM
//  * @tc.type: FUNC
//  * @tc.level Level 1
//  * @tc.require: SR000H63TL
//  */
// HWTEST_F(HapInfoSegmentTest, fromByteArray, testing::ext::TestSize.Level1)
// {
//     std::shared_ptr<HapInfoSegment> api(new HapInfoSegment());
    
//     std::vector<int8_t> bytes{ 12, 45, 58, -12, 38, 29, 12, 45, 58, -12, 38, 29, 12, 45, 58, -12, 38, 29, 12, 45, 58, -12, 38, 29, 12, 45, 58, -12, 38, 29, 13, 26,
//     12, 45, 58, -12, 38, 29, 12, 45, 58, -12, 38, 29, 12, 45, 58, -12, 38, 29, 12, 45, 58, -12, 38, 29, 12, 45, 58, -12, 38, 29, 13, 26 };
//     api->fromByteArray(bytes);

//     EXPECT_NE(true, 1);
// }

/**
 * @tc.name: getSignInfo
 * @tc.desc: Test function of SignToolServiceImpl::GenerateCsr() interface for SUCCESS.
 * @tc.size: MEDIUM
 * @tc.type: FUNC
 * @tc.level Level 1
 * @tc.require: SR000H63TL
 */
HWTEST_F(HapInfoSegmentTest, getSignInfo, testing::ext::TestSize.Level1)
{
    std::shared_ptr<HapInfoSegment> api(new HapInfoSegment());

    api->getSignInfo();

    EXPECT_NE(true, 1);
}

/**
 * @tc.name: getSize
 * @tc.desc: Test function of SignToolServiceImpl::GenerateCsr() interface for SUCCESS.
 * @tc.size: MEDIUM
 * @tc.type: FUNC
 * @tc.level Level 1
 * @tc.require: SR000H63TL
 */
HWTEST_F(HapInfoSegmentTest, getSize, testing::ext::TestSize.Level1)
{
    std::shared_ptr<HapInfoSegment> api(new HapInfoSegment());

    int32_t hapInfoSegmentSize = api->getSize();

    EXPECT_EQ(hapInfoSegmentSize, 0);
}

/**
 * @tc.name: setSignInfo
 * @tc.desc: Test function of SignToolServiceImpl::GenerateCsr() interface for SUCCESS.
 * @tc.size: MEDIUM
 * @tc.type: FUNC
 * @tc.level Level 1
 * @tc.require: SR000H63TL
 */
HWTEST_F(HapInfoSegmentTest, setSignInfo, testing::ext::TestSize.Level1)
{
    std::shared_ptr<HapInfoSegment> api(new HapInfoSegment());

    int32_t saltSize = 0;
    int32_t flags = 1;
    int64_t dataSize = 5390336;
    std::vector<int8_t> salt;
    std::vector<int8_t> sig{ 48, -126, 7, -46, 6, 9, 42, -122, 72, -122, -9, 13, 1, 7, 2, -96, -126, 7, -61, 48, -126, 7, -65, 2, 1, 1, 49, 13, 48, 11, 6, 9, 96, -122, 72, 1, 101, 3, 4, 2, 1, 48, 11, 6, 9, 42, -122, 72, -122, -9, 13, 1, 7, 1, -96, -126, 6, 43, 48, -126, 1, -32, 48, -126, 1, -121, -96, 3, 2, 1, 2, 2, 4, 85, -67, -54, 116, 48, 10, 6, 8, 42, -122, 72, -50, 61, 4, 3, 3, 48, 85, 49, 11, 48, 9, 6, 3, 85, 4, 6, 1 };
    SignInfo signInfo(saltSize, flags, dataSize, salt, sig);
    api->setSignInfo(signInfo);

    EXPECT_EQ(true, 1);
}

/**
 * @tc.name: toByteArray
 * @tc.desc: Test function of SignToolServiceImpl::GenerateCsr() interface for SUCCESS.
 * @tc.size: MEDIUM
 * @tc.type: FUNC
 * @tc.level Level 1
 * @tc.require: SR000H63TL
 */
HWTEST_F(HapInfoSegmentTest, toByteArray, testing::ext::TestSize.Level1)
{
    std::shared_ptr<HapInfoSegment> api(new HapInfoSegment());
    
    std::vector<int8_t> byteArray = api->toByteArray();

    EXPECT_EQ(byteArray.size(), 0);
}
