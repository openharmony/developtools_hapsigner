/*
 * Copyright (c) 2021-2023 Huawei Device Co., Ltd.
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *     http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */

#include <memory>
#include <gtest/gtest.h>
#include "merkle_tree_extension.h"

using namespace OHOS::SignatureTools;

/*
* �����׼�,�̶�д��
*/
class MerkleTreeExtensionTest : public testing::Test
{
public:
    static void SetUpTestCase(void) {};
    static void TearDownTestCase() {};
    void SetUp() {};
    void TearDown() {};
};

// /**
//  * @tc.name: fromByteArray
//  * @tc.desc: Test function of SignToolServiceImpl::GenerateCsr() interface for SUCCESS.
//  * @tc.size: MEDIUM
//  * @tc.type: FUNC
//  * @tc.level Level 1
//  * @tc.require: SR000H63TL
//  */
// HWTEST_F(MerkleTreeExtensionTest, fromByteArray, testing::ext::TestSize.Level1)
// {
//     std::shared_ptr<MerkleTreeExtension> api(new MerkleTreeExtension());
   
//     std::vector<int8_t> byteArray = { 11, -93, 88, 107, -121, 96, 121, 23, -64, -58, -95, -71, -126, 60, 116, 60, 10, 15, -125, 107, 127, -123, 81, 68, 28, -121, -20, -42, -116, -81, -6, 118, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0 };
//     Extension* pExtension = api->fromByteArray(byteArray);

//     EXPECT_EQ(pExtension, nullptr);
// }

/**
 * @tc.name: getMerkleTreeOffset
 * @tc.desc: Test function of SignToolServiceImpl::GenerateCsr() interface for SUCCESS.
 * @tc.size: MEDIUM
 * @tc.type: FUNC
 * @tc.level Level 1
 * @tc.require: SR000H63TL
 */
HWTEST_F(MerkleTreeExtensionTest, getMerkleTreeOffset, testing::ext::TestSize.Level1)
{
    std::shared_ptr<MerkleTreeExtension> api(new MerkleTreeExtension());

    int64_t merkleTreeOffset = api->getMerkleTreeOffset();

    EXPECT_EQ(merkleTreeOffset, 0);
}

/**
 * @tc.name: getMerkleTreeSize
 * @tc.desc: Test function of SignToolServiceImpl::GenerateCsr() interface for SUCCESS.
 * @tc.size: MEDIUM
 * @tc.type: FUNC
 * @tc.level Level 1
 * @tc.require: SR000H63TL
 */
HWTEST_F(MerkleTreeExtensionTest, getMerkleTreeSize, testing::ext::TestSize.Level1)
{
    std::shared_ptr<MerkleTreeExtension> api(new MerkleTreeExtension());

    int64_t merkleTreeSize = api->getMerkleTreeSize();

    EXPECT_EQ(merkleTreeSize, 0);
}

/**
 * @tc.name: getSize
 * @tc.desc: Test function of SignToolServiceImpl::GenerateCsr() interface for SUCCESS.
 * @tc.size: MEDIUM
 * @tc.type: FUNC
 * @tc.level Level 1
 * @tc.require: SR000H63TL
 */
HWTEST_F(MerkleTreeExtensionTest, getSize, testing::ext::TestSize.Level1)
{
    std::shared_ptr<MerkleTreeExtension> api(new MerkleTreeExtension());

    int32_t merkleTreeExtensionSize = api->getSize();

    EXPECT_EQ(merkleTreeExtensionSize, 0);
}

/**
 * @tc.name: isType
 * @tc.desc: Test function of SignToolServiceImpl::GenerateCsr() interface for SUCCESS.
 * @tc.size: MEDIUM
 * @tc.type: FUNC
 * @tc.level Level 1
 * @tc.require: SR000H63TL
 */
HWTEST_F(MerkleTreeExtensionTest, isType, testing::ext::TestSize.Level1)
{
    std::shared_ptr<MerkleTreeExtension> api(new MerkleTreeExtension());

    int32_t type = 1;
    bool bIsType = api->isType(type);

    EXPECT_EQ(bIsType, false);
}

/**
 * @tc.name: setMerkleTreeOffset
 * @tc.desc: Test function of SignToolServiceImpl::GenerateCsr() interface for SUCCESS.
 * @tc.size: MEDIUM
 * @tc.type: FUNC
 * @tc.level Level 1
 * @tc.require: SR000H63TL
 */
HWTEST_F(MerkleTreeExtensionTest, setMerkleTreeOffset, testing::ext::TestSize.Level1)
{
    std::shared_ptr<MerkleTreeExtension> api(new MerkleTreeExtension());

    int64_t offset = 927046;
    api->setMerkleTreeOffset(offset);

    EXPECT_EQ(true, 1);
}

/**
 * @tc.name: toByteArray
 * @tc.desc: Test function of SignToolServiceImpl::GenerateCsr() interface for SUCCESS.
 * @tc.size: MEDIUM
 * @tc.type: FUNC
 * @tc.level Level 1
 * @tc.require: SR000H63TL
 */
HWTEST_F(MerkleTreeExtensionTest, toByteArray, testing::ext::TestSize.Level1)
{
    std::shared_ptr<MerkleTreeExtension> api(new MerkleTreeExtension());

    std::vector<int8_t> byteArray = api->toByteArray();

    EXPECT_EQ(byteArray.size(), 0);
}

/**
 * @tc.name: toString
 * @tc.desc: Test function of SignToolServiceImpl::GenerateCsr() interface for SUCCESS.
 * @tc.size: MEDIUM
 * @tc.type: FUNC
 * @tc.level Level 1
 * @tc.require: SR000H63TL
 */
HWTEST_F(MerkleTreeExtensionTest, toString, testing::ext::TestSize.Level1)
{
    std::shared_ptr<MerkleTreeExtension> api(new MerkleTreeExtension());

    std::string str = api->toString();

    EXPECT_EQ(str.size(), 0);
}
