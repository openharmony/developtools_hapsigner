/*
 * Copyright (c) 2021-2023 Huawei Device Co., Ltd.
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *     http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */

#include <memory>
#include <gtest/gtest.h>
#include "ca.h"

//using namespace OHOS::SignatureTools;

/*
* �����׼�,�̶�д��
*/
class CATest : public testing::Test
{
public:
    static void SetUpTestCase(void) {};
    static void TearDownTestCase() {};
    void SetUp() {};
    void TearDown() {};
};

// /**
//  * @tc.name: ecToevp
//  * @tc.desc: Test function of SignToolServiceImpl::GenerateCsr() interface for SUCCESS.
//  * @tc.size: MEDIUM
//  * @tc.type: FUNC
//  * @tc.level Level 1
//  * @tc.require: SR000H63TL
//  */
// HWTEST_F(CATest, ecToevp, testing::ext::TestSize.Level1)
// {
//     std::shared_ptr<CA> api(new CA);

//     EC_KEY* ec = nullptr;
//     EVP_PKEY* evp = api->ecToevp(ec);

//     EXPECT_EQ(evp, nullptr);
// }

// /**
//  * @tc.name: GenerateCertificate
//  * @tc.desc: Test function of SignToolServiceImpl::GenerateCsr() interface for SUCCESS.
//  * @tc.size: MEDIUM
//  * @tc.type: FUNC
//  * @tc.level Level 1
//  * @tc.require: SR000H63TL
//  */
// HWTEST_F(CATest, GenerateCertificate, testing::ext::TestSize.Level1)
// {
//     std::shared_ptr<CA> api(new CA);
    
//     HashType hashAlg = HASH_SHA256;
//     std::string country;
//     std::string organization;
//     std::string organi_Unit;
//     std::string domainl;
//     int validity = 365;
//     X509* pX509 = api->GenerateCertificate(hashAlg, country, organization, organi_Unit, domainl, validity);

//     EXPECT_EQ(pX509, nullptr);
// }

// /**
//  * @tc.name: GenerateCsrReq
//  * @tc.desc: Test function of SignToolServiceImpl::GenerateCsr() interface for SUCCESS.
//  * @tc.size: MEDIUM
//  * @tc.type: FUNC
//  * @tc.level Level 1
//  * @tc.require: SR000H63TL
//  */
// HWTEST_F(CATest, GenerateCsrReq, testing::ext::TestSize.Level1)
// {
//     std::shared_ptr<CA> api(new CA);
    
//     HashType hashAlg = HASH_SHA256;
//     std::string country;
//     std::string organization;
//     std::string organi_Unit;
//     std::string domain;
//     X509_REQ* pX509_REQ = api->GenerateCsrReq(hashAlg, country, organization, organi_Unit, domain);

//     EXPECT_EQ(pX509_REQ, nullptr);
// }

/**
 * @tc.name: GenerateKeyPair
 * @tc.desc: Test function of SignToolServiceImpl::GenerateCsr() interface for SUCCESS.
 * @tc.size: MEDIUM
 * @tc.type: FUNC
 * @tc.level Level 1
 * @tc.require: SR000H63TL
 */
HWTEST_F(CATest, GenerateKeyPair, testing::ext::TestSize.Level1)
{
    std::shared_ptr<CA> api(new CA);
    
    CurveType ct = CURVE256;
    EC_KEY* pECKEY = api->GenerateKeyPair(ct);

    EXPECT_EQ(pECKEY, nullptr);
}

// /**
//  * @tc.name: GeneratesubCa
//  * @tc.desc: Test function of SignToolServiceImpl::GenerateCsr() interface for SUCCESS.
//  * @tc.size: MEDIUM
//  * @tc.type: FUNC
//  * @tc.level Level 1
//  * @tc.require: SR000H63TL
//  */
// HWTEST_F(CATest, GeneratesubCa, testing::ext::TestSize.Level1)
// {
//     std::shared_ptr<CA> api(new CA);
   
//     CurveType curve = CURVE256;
//     HashType hashAlgstring = HASH_SHA256;
//     std::string subPubkeyFile;
//     std::string subPrikeyFile;
//     std::string caPrifile;
//     std::string subCountry;
//     std::string subOrganization;
//     std::string subOrgani_Unit;
//     std::string subDomainstring;
//     std::string subCsrfile;
//     std::string subCafile;
//     X509* ca = nullptr;
//     int validity = 365;
//     api->GeneratesubCa(curve, hashAlgstring, subPubkeyFile, subPrikeyFile, caPrifile, subCountry, subOrganization, subOrgani_Unit, subDomainstring, subCsrfile, subCafile, ca, validity);

//     EXPECT_EQ(true, 1);
// }

/**
 * @tc.name: GetCertOb
 * @tc.desc: Test function of SignToolServiceImpl::GenerateCsr() interface for SUCCESS.
 * @tc.size: MEDIUM
 * @tc.type: FUNC
 * @tc.level Level 1
 * @tc.require: SR000H63TL
 */
HWTEST_F(CATest, GetCertOb, testing::ext::TestSize.Level1)
{
    std::shared_ptr<CA> api(new CA);
    
    X509* pX509 = api->GetCertOb();

    EXPECT_EQ(pX509, nullptr);
}

/**
 * @tc.name: SaveCsrTofile
 * @tc.desc: Test function of SignToolServiceImpl::GenerateCsr() interface for SUCCESS.
 * @tc.size: MEDIUM
 * @tc.type: FUNC
 * @tc.level Level 1
 * @tc.require: SR000H63TL
 */
HWTEST_F(CATest, SaveCsrTofile, testing::ext::TestSize.Level1)
{
    std::shared_ptr<CA> api(new CA);

    const std::string filename;
    X509_REQ* cer = nullptr;

    api->SaveCsrTofile(filename, cer);

    EXPECT_EQ(true, 1);
}

/**
 * @tc.name: SavekeyTofile
 * @tc.desc: Test function of SignToolServiceImpl::GenerateCsr() interface for SUCCESS.
 * @tc.size: MEDIUM
 * @tc.type: FUNC
 * @tc.level Level 1
 * @tc.require: SR000H63TL
 */
HWTEST_F(CATest, SavekeyTofile, testing::ext::TestSize.Level1)
{
    std::shared_ptr<CA> api(new CA);

    const std::string pubFile;
    const std::string priFile;
    EC_KEY* key = nullptr;
    api->SavekeyTofile(pubFile, priFile, key);

    EXPECT_EQ(true, 1);
}

/**
 * @tc.name: SetcerOtherinfo
 * @tc.desc: Test function of SignToolServiceImpl::GenerateCsr() interface for SUCCESS.
 * @tc.size: MEDIUM
 * @tc.type: FUNC
 * @tc.level Level 1
 * @tc.require: SR000H63TL
 */
HWTEST_F(CATest, SetcerOtherinfo, testing::ext::TestSize.Level1)
{
    std::shared_ptr<CA> api(new CA);
    
    int validity = 365;
    X509* pX509 = api->SetcerOtherinfo(validity);

    EXPECT_EQ(pX509, nullptr);
}

/**
 * @tc.name: Setsubject
 * @tc.desc: Test function of SignToolServiceImpl::GenerateCsr() interface for SUCCESS.
 * @tc.size: MEDIUM
 * @tc.type: FUNC
 * @tc.level Level 1
 * @tc.require: SR000H63TL
 */
HWTEST_F(CATest, Setsubject, testing::ext::TestSize.Level1)
{
    std::shared_ptr<CA> api(new CA);
    
    std::string country;
    std::string organization;
    std::string organi_Unit;
    std::string domain;
    X509_NAME* name = nullptr;
    X509_NAME* pX509_NAME = api->Setsubject(country, organization, organi_Unit, domain, name);

    EXPECT_EQ(pX509_NAME, nullptr);
}

// /**
//  * @tc.name: SignCsrGenerateCer
//  * @tc.desc: Test function of SignToolServiceImpl::GenerateCsr() interface for SUCCESS.
//  * @tc.size: MEDIUM
//  * @tc.type: FUNC
//  * @tc.level Level 1
//  * @tc.require: SR000H63TL
//  */
// HWTEST_F(CATest, SignCsrGenerateCer, testing::ext::TestSize.Level1)
// {
//     std::shared_ptr<CA> api(new CA);
   
//     const std::string csrFilename;
//     const std::string caKeyfilename;
//     X509* Cert = nullptr;
//     int validity = 365;
//     X509* pX509 = api->SignCsrGenerateCer(csrFilename, caKeyfilename, Cert, validity);

//     EXPECT_EQ(pX509, nullptr);
// }

/**
 * @tc.name: VerifyCsrSignature
 * @tc.desc: Test function of SignToolServiceImpl::GenerateCsr() interface for SUCCESS.
 * @tc.size: MEDIUM
 * @tc.type: FUNC
 * @tc.level Level 1
 * @tc.require: SR000H63TL
 */
HWTEST_F(CATest, VerifyCsrSignature, testing::ext::TestSize.Level1)
{
    std::shared_ptr<CA> api(new CA);
    
    const std::string csrFilename;
    bool flag = api->VerifyCsrSignature(csrFilename);

    EXPECT_EQ(flag, false);
}
