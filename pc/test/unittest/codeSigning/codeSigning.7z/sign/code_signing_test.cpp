/*
 * Copyright (c) 2021-2023 Huawei Device Co., Ltd.
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *     http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */

#include <memory>
#include <fstream>
#include <gtest/gtest.h>
#include "code_signing.h"
#include "zip_signer.h"

using namespace OHOS::SignatureTools;

/*
* �����׼�,�̶�д��
*/
class CodeSigningTest : public testing::Test
{
public:
    static void SetUpTestCase(void) {};
    static void TearDownTestCase() {};
    void SetUp() {};
    void TearDown() {};
};

// /**
//  * @tc.name: computeDataSize
//  * @tc.desc: Test function of SignToolServiceImpl::GenerateCsr() interface for SUCCESS.
//  * @tc.size: MEDIUM
//  * @tc.type: FUNC
//  * @tc.level Level 1
//  * @tc.require: SR000H63TL
//  */
// HWTEST_F(CodeSigningTest, computeDataSize, testing::ext::TestSize.Level1)
// {
//     SignerConfig signerConfig;
//     signerConfig.SetCompatibleVersion(9);

//     std::map<std::string, std::string> params;
//     params["keyPwd"] = "123456";
//     params["mode"] = "localSign";
//     params["keyAlias"] = "oh-app1-key-v1";
//     params["signAlg"] = "SHA256withECDSA";
//     params["appCertFile"] = "./test/app-release1.pem";
//     params["signCode"] = "1";
//     params["compatibleVersion"] = "9";
//     params["outFile"] = "./entry-default-signed-so.hap";
//     params["profileFile"] = "./test/signed-profile.p7b";
//     params["keystorePwd"] = "123456";
//     params["keystoreFile"] = "./test/ohtest.jks";
//     params["inFile"] = "./entry-default-unsigned-so.hap";
//     params["profileSigned"] = "1";
//     signerConfig.FillParameters(params);

//     ContentDigestAlgorithm contentDigestAlgorithm("SHA-256", 32);
//     std::pair<std::string, void*> signatureAlgAndParams("SHA256withECDSA", nullptr);
//     SignatureAlgorithmClass signatureAlgorithm(SignatureAlgorithmId::DSA_WITH_SHA256, "ECDSA_WITH_SHA256", contentDigestAlgorithm, signatureAlgAndParams);
//     std::vector<SignatureAlgorithmClass> signatureAlgorithms;
//     signatureAlgorithms.push_back(signatureAlgorithm);
//     signerConfig.SetSignatureAlgorithms(signatureAlgorithms);

//     Options options;
//     options.emplace("mode", std::string("localSign"));
//     options.emplace("keyPwd", std::string("123456"));
//     options.emplace("outFile", std::string("./entry-default-signed-so.hap"));
//     options.emplace("keyAlias", std::string("oh-app1-key-v1"));
//     options.emplace("profileFile", std::string("./test/signed-profile.p7b"));
//     options.emplace("signAlg", std::string("SHA256withECDSA"));
//     options.emplace("keystorePwd", std::string("123456"));
//     options.emplace("keystoreFile", std::string("./test/ohtest.jks"));
//     options.emplace("appCertFile", std::string("./test/app-release1.pem"));
//     options.emplace("inFile", std::string("./entry-default-unsigned-so.hap"));
//     signerConfig.SetOptions(&options);

//     CodeSigning codeSigning(signerConfig);

//     std::string input = "entry-default-unsigned-so.hap";
//     std::string output = "entry-default-signed-so.hap";
//     std::ifstream inputStream(input, std::ios::binary);
//     std::ofstream outputStream(output, std::ios::binary);
//     Zip zip;
//     zip.Init(inputStream);
//     zip.Alignment(1);
//     zip.RemoveSignBlock();
//     zip.ToFile(inputStream, outputStream);

//     int64_t dataSize = codeSigning.computeDataSize(zip);

//     EXPECT_EQ(dataSize, 0);
// }

/**
 * @tc.name: generateSignature
 * @tc.desc: Test function of SignToolServiceImpl::GenerateCsr() interface for SUCCESS.
 * @tc.size: MEDIUM
 * @tc.type: FUNC
 * @tc.level Level 1
 * @tc.require: SR000H63TL
 */
HWTEST_F(CodeSigningTest, generateSignature, testing::ext::TestSize.Level1)
{
    SignerConfig signerConfig;
    signerConfig.SetCompatibleVersion(9);

    std::map<std::string, std::string> params;
    params["keyPwd"] = "123456";
    params["mode"] = "localSign";
    params["keyAlias"] = "oh-app1-key-v1";
    params["signAlg"] = "SHA256withECDSA";
    params["appCertFile"] = "./test/app-release1.pem";
    params["signCode"] = "1";
    params["compatibleVersion"] = "9";
    params["outFile"] = "./entry-default-signed-so.hap";
    params["profileFile"] = "./test/signed-profile.p7b";
    params["keystorePwd"] = "123456";
    params["keystoreFile"] = "./test/ohtest.jks";
    params["inFile"] = "./entry-default-unsigned-so.hap";
    params["profileSigned"] = "1";
    signerConfig.FillParameters(params);

    ContentDigestAlgorithm contentDigestAlgorithm("SHA-256", 32);
    std::pair<std::string, void*> signatureAlgAndParams("SHA256withECDSA", nullptr);
    SignatureAlgorithmClass signatureAlgorithm(SignatureAlgorithmId::DSA_WITH_SHA256, "ECDSA_WITH_SHA256", contentDigestAlgorithm, signatureAlgAndParams);
    std::vector<SignatureAlgorithmClass> signatureAlgorithms;
    signatureAlgorithms.push_back(signatureAlgorithm);
    signerConfig.SetSignatureAlgorithms(signatureAlgorithms);

    Options options;
    options.emplace("mode", std::string("localSign"));
    options.emplace("keyPwd", std::string("123456"));
    options.emplace("outFile", std::string("./entry-default-signed-so.hap"));
    options.emplace("keyAlias", std::string("oh-app1-key-v1"));
    options.emplace("profileFile", std::string("./test/signed-profile.p7b"));
    options.emplace("signAlg", std::string("SHA256withECDSA"));
    options.emplace("keystorePwd", std::string("123456"));
    options.emplace("keystoreFile", std::string("./test/ohtest.jks"));
    options.emplace("appCertFile", std::string("./test/app-release1.pem"));
    options.emplace("inFile", std::string("./entry-default-unsigned-so.hap"));
    signerConfig.SetOptions(&options);

    CodeSigning codeSigning(signerConfig);

    std::vector<int8_t> signedData = { 70, 83, 86, 101, 114, 105, 116, 121, 1,
        0, 32, 0, -82, 98, 15, 102, 95, -26, -90, 88, 83, 8, -42, -65, -121,
        117, -43, -95, -102, -56, 109, 93, 25, -9, -88, 44, -25, 119, -39, -68,
        -15, 11, 123, -80 };
    std::string ownerID;
    std::vector<int8_t> ret;
    bool flag = codeSigning.generateSignature(signedData, ownerID, ret);

    EXPECT_EQ(flag, false);
}

// /**
//  * @tc.name: getCodeSignBlock
//  * @tc.desc: Test function of SignToolServiceImpl::GenerateCsr() interface for SUCCESS.
//  * @tc.size: MEDIUM
//  * @tc.type: FUNC
//  * @tc.level Level 1
//  * @tc.require: SR000H63TL
//  */
// HWTEST_F(CodeSigningTest, getCodeSignBlock, testing::ext::TestSize.Level1)
// {
//     SignerConfig signerConfig;
//     signerConfig.SetCompatibleVersion(9);

//     std::map<std::string, std::string> params;
//     params["keyPwd"] = "123456";
//     params["mode"] = "localSign";
//     params["keyAlias"] = "oh-app1-key-v1";
//     params["signAlg"] = "SHA256withECDSA";
//     params["appCertFile"] = "./test/app-release1.pem";
//     params["signCode"] = "1";
//     params["compatibleVersion"] = "9";
//     params["outFile"] = "./entry-default-signed-so.hap";
//     params["profileFile"] = "./test/signed-profile.p7b";
//     params["keystorePwd"] = "123456";
//     params["keystoreFile"] = "./test/ohtest.jks";
//     params["inFile"] = "./entry-default-unsigned-so.hap";
//     params["profileSigned"] = "1";
//     signerConfig.FillParameters(params);

//     ContentDigestAlgorithm contentDigestAlgorithm("SHA-256", 32);
//     std::pair<std::string, void*> signatureAlgAndParams("SHA256withECDSA", nullptr);
//     SignatureAlgorithmClass signatureAlgorithm(SignatureAlgorithmId::DSA_WITH_SHA256, "ECDSA_WITH_SHA256", contentDigestAlgorithm, signatureAlgAndParams);
//     std::vector<SignatureAlgorithmClass> signatureAlgorithms;
//     signatureAlgorithms.push_back(signatureAlgorithm);
//     signerConfig.SetSignatureAlgorithms(signatureAlgorithms);

//     Options options;
//     options.emplace("mode", std::string("localSign"));
//     options.emplace("keyPwd", std::string("123456"));
//     options.emplace("outFile", std::string("./entry-default-signed-so.hap"));
//     options.emplace("keyAlias", std::string("oh-app1-key-v1"));
//     options.emplace("profileFile", std::string("./test/signed-profile.p7b"));
//     options.emplace("signAlg", std::string("SHA256withECDSA"));
//     options.emplace("keystorePwd", std::string("123456"));
//     options.emplace("keystoreFile", std::string("./test/ohtest.jks"));
//     options.emplace("appCertFile", std::string("./test/app-release1.pem"));
//     options.emplace("inFile", std::string("./entry-default-unsigned-so.hap"));
//     signerConfig.SetOptions(&options);

//     CodeSigning codeSigning(signerConfig);
    
//     int64_t offset = 1397151;
//     std::string inForm = "hap";
//     std::string profileContent = "{\"bundle-info\":{\"app-feature\":\"hos_system_app\",\"bundle-name\":\"com.OpenHarmony.app.test\",\"developer-id\":\"OpenHarmony\",\"development-certificate\":\"-----BEGIN CERTIFICATE-----\\nMIICMzCCAbegAwIBAgIEaOC/zDAMBggqhkjOPQQDAwUAMGMxCzAJBgNVBAYTAkNO\\nMRQwEgYDVQQKEwtPcGVuSGFybW9ueTEZMBcGA1UECxMQT3Blbkhhcm1vbnkgVGVh\\nbTEjMCEGA1UEAxMaT3Blbkhhcm1vbnkgQXBwbGljYXRpb24gQ0EwHhcNMjEwMjAy\\nMTIxOTMxWhcNNDkxMjMxMTIxOTMxWjBoMQswCQYDVQQGEwJDTjEUMBIGA1UEChML\\nT3Blbkhhcm1vbnkxGTAXBgNVBAsTEE9wZW5IYXJtb255IFRlYW0xKDAmBgNVBAMT\\nH09wZW5IYXJtb255IEFwcGxpY2F0aW9uIFJlbGVhc2UwWTATBgcqhkjOPQIBBggq\\nhkjOPQMBBwNCAATbYOCQQpW5fdkYHN45v0X3AHax12jPBdEDosFRIZ1eXmxOYzSG\\nJwMfsHhUU90E8lI0TXYZnNmgM1sovubeQqATo1IwUDAfBgNVHSMEGDAWgBTbhrci\\nFtULoUu33SV7ufEFfaItRzAOBgNVHQ8BAf8EBAMCB4AwHQYDVR0OBBYEFPtxruhl\\ncRBQsJdwcZqLu9oNUVgaMAwGCCqGSM49BAMDBQADaAAwZQIxAJta0PQ2p4DIu/ps\\nLMdLCDgQ5UH1l0B4PGhBlMgdi2zf8nk9spazEQI/0XNwpft8QAIwHSuA2WelVi/o\\nzAlF08DnbJrOOtOnQq5wHOPlDYB4OtUzOYJk9scotrEnJxJzGsh/\\n-----END CERTIFICATE-----\\n\"},\"debug-info\":{\"device-id-type\":\"udid\",\"device-ids\":[\"69C7505BE341BDA5948C3C0CB44ABCD530296054159EFE0BD16A16CD0129CC42\",\"7EED06506FCE6325EB2E2FAA019458B856AB10493A6718C7679A73F958732865\"]},\"issuer\":\"pki_internal\",\"permissions\":{\"restricted-permissions\":[\"\"]},\"type\":\"debug\",\"uuid\":\"fe686e1b-3770-4824-a938-961b140a7c98\",\"validity\":{\"not-after\":1705127532,\"not-before\":1610519532},\"version-code\":1,\"version-name\":\"1.0.0\"}";

//     std::string input = "entry-default-unsigned-so.hap";
//     std::string output = "entry-default-signed-so.hap";
//     std::ifstream inputStream(input, std::ios::binary);
//     std::ofstream outputStream(output, std::ios::binary);
//     Zip zip;
//     zip.Init(inputStream);
//     zip.Alignment(1);
//     zip.RemoveSignBlock();
//     zip.ToFile(inputStream, outputStream);

//     std::vector<int8_t> ret;
//     bool flag = codeSigning.getCodeSignBlock(input, offset, inForm, profileContent, zip, ret);

//     EXPECT_EQ(flag, false);
// }

/**
 * @tc.name: GetNativeEntriesFromHap
 * @tc.desc: Test function of SignToolServiceImpl::GenerateCsr() interface for SUCCESS.
 * @tc.size: MEDIUM
 * @tc.type: FUNC
 * @tc.level Level 1
 * @tc.require: SR000H63TL
 */
HWTEST_F(CodeSigningTest, GetNativeEntriesFromHap, testing::ext::TestSize.Level1)
{
    SignerConfig signerConfig;
    signerConfig.SetCompatibleVersion(9);

    std::map<std::string, std::string> params;
    params["keyPwd"] = "123456";
    params["mode"] = "localSign";
    params["keyAlias"] = "oh-app1-key-v1";
    params["signAlg"] = "SHA256withECDSA";
    params["appCertFile"] = "./test/app-release1.pem";
    params["signCode"] = "1";
    params["compatibleVersion"] = "9";
    params["outFile"] = "./entry-default-signed-so.hap";
    params["profileFile"] = "./test/signed-profile.p7b";
    params["keystorePwd"] = "123456";
    params["keystoreFile"] = "./test/ohtest.jks";
    params["inFile"] = "./entry-default-unsigned-so.hap";
    params["profileSigned"] = "1";
    signerConfig.FillParameters(params);

    ContentDigestAlgorithm contentDigestAlgorithm("SHA-256", 32);
    std::pair<std::string, void*> signatureAlgAndParams("SHA256withECDSA", nullptr);
    SignatureAlgorithmClass signatureAlgorithm(SignatureAlgorithmId::DSA_WITH_SHA256, "ECDSA_WITH_SHA256", contentDigestAlgorithm, signatureAlgAndParams);
    std::vector<SignatureAlgorithmClass> signatureAlgorithms;
    signatureAlgorithms.push_back(signatureAlgorithm);
    signerConfig.SetSignatureAlgorithms(signatureAlgorithms);

    Options options;
    options.emplace("mode", std::string("localSign"));
    options.emplace("keyPwd", std::string("123456"));
    options.emplace("outFile", std::string("./entry-default-signed-so.hap"));
    options.emplace("keyAlias", std::string("oh-app1-key-v1"));
    options.emplace("profileFile", std::string("./test/signed-profile.p7b"));
    options.emplace("signAlg", std::string("SHA256withECDSA"));
    options.emplace("keystorePwd", std::string("123456"));
    options.emplace("keystoreFile", std::string("./test/ohtest.jks"));
    options.emplace("appCertFile", std::string("./test/app-release1.pem"));
    options.emplace("inFile", std::string("./entry-default-unsigned-so.hap"));
    signerConfig.SetOptions(&options);

    CodeSigning codeSigning(signerConfig);
   
    std::string packageName = "libs/arm64-v8a/libc++_shared.so";
    std::vector<std::tuple<std::string, std::stringbuf, uLong>> ret = codeSigning.GetNativeEntriesFromHap(packageName);

    EXPECT_EQ(ret.size(), false);
}

/**
 * @tc.name: getTimestamp
 * @tc.desc: Test function of SignToolServiceImpl::GenerateCsr() interface for SUCCESS.
 * @tc.size: MEDIUM
 * @tc.type: FUNC
 * @tc.level Level 1
 * @tc.require: SR000H63TL
 */
HWTEST_F(CodeSigningTest, getTimestamp, testing::ext::TestSize.Level1)
{
    SignerConfig signerConfig;
    signerConfig.SetCompatibleVersion(9);

    std::map<std::string, std::string> params;
    params["keyPwd"] = "123456";
    params["mode"] = "localSign";
    params["keyAlias"] = "oh-app1-key-v1";
    params["signAlg"] = "SHA256withECDSA";
    params["appCertFile"] = "./test/app-release1.pem";
    params["signCode"] = "1";
    params["compatibleVersion"] = "9";
    params["outFile"] = "./entry-default-signed-so.hap";
    params["profileFile"] = "./test/signed-profile.p7b";
    params["keystorePwd"] = "123456";
    params["keystoreFile"] = "./test/ohtest.jks";
    params["inFile"] = "./entry-default-unsigned-so.hap";
    params["profileSigned"] = "1";
    signerConfig.FillParameters(params);

    ContentDigestAlgorithm contentDigestAlgorithm("SHA-256", 32);
    std::pair<std::string, void*> signatureAlgAndParams("SHA256withECDSA", nullptr);
    SignatureAlgorithmClass signatureAlgorithm(SignatureAlgorithmId::DSA_WITH_SHA256, "ECDSA_WITH_SHA256", contentDigestAlgorithm, signatureAlgAndParams);
    std::vector<SignatureAlgorithmClass> signatureAlgorithms;
    signatureAlgorithms.push_back(signatureAlgorithm);
    signerConfig.SetSignatureAlgorithms(signatureAlgorithms);

    Options options;
    options.emplace("mode", std::string("localSign"));
    options.emplace("keyPwd", std::string("123456"));
    options.emplace("outFile", std::string("./entry-default-signed-so.hap"));
    options.emplace("keyAlias", std::string("oh-app1-key-v1"));
    options.emplace("profileFile", std::string("./test/signed-profile.p7b"));
    options.emplace("signAlg", std::string("SHA256withECDSA"));
    options.emplace("keystorePwd", std::string("123456"));
    options.emplace("keystoreFile", std::string("./test/ohtest.jks"));
    options.emplace("appCertFile", std::string("./test/app-release1.pem"));
    options.emplace("inFile", std::string("./entry-default-unsigned-so.hap"));
    signerConfig.SetOptions(&options);

    CodeSigning codeSigning(signerConfig);
   
    int64_t timeStamp = codeSigning.getTimestamp();

    EXPECT_EQ(timeStamp, 0);
}

/**
 * @tc.name: isNativeFile
 * @tc.desc: Test function of SignToolServiceImpl::GenerateCsr() interface for SUCCESS.
 * @tc.size: MEDIUM
 * @tc.type: FUNC
 * @tc.level Level 1
 * @tc.require: SR000H63TL
 */
HWTEST_F(CodeSigningTest, isNativeFile, testing::ext::TestSize.Level1)
{
    SignerConfig signerConfig;
    signerConfig.SetCompatibleVersion(9);

    std::map<std::string, std::string> params;
    params["keyPwd"] = "123456";
    params["mode"] = "localSign";
    params["keyAlias"] = "oh-app1-key-v1";
    params["signAlg"] = "SHA256withECDSA";
    params["appCertFile"] = "./test/app-release1.pem";
    params["signCode"] = "1";
    params["compatibleVersion"] = "9";
    params["outFile"] = "./entry-default-signed-so.hap";
    params["profileFile"] = "./test/signed-profile.p7b";
    params["keystorePwd"] = "123456";
    params["keystoreFile"] = "./test/ohtest.jks";
    params["inFile"] = "./entry-default-unsigned-so.hap";
    params["profileSigned"] = "1";
    signerConfig.FillParameters(params);

    ContentDigestAlgorithm contentDigestAlgorithm("SHA-256", 32);
    std::pair<std::string, void*> signatureAlgAndParams("SHA256withECDSA", nullptr);
    SignatureAlgorithmClass signatureAlgorithm(SignatureAlgorithmId::DSA_WITH_SHA256, "ECDSA_WITH_SHA256", contentDigestAlgorithm, signatureAlgAndParams);
    std::vector<SignatureAlgorithmClass> signatureAlgorithms;
    signatureAlgorithms.push_back(signatureAlgorithm);
    signerConfig.SetSignatureAlgorithms(signatureAlgorithms);

    Options options;
    options.emplace("mode", std::string("localSign"));
    options.emplace("keyPwd", std::string("123456"));
    options.emplace("outFile", std::string("./entry-default-signed-so.hap"));
    options.emplace("keyAlias", std::string("oh-app1-key-v1"));
    options.emplace("profileFile", std::string("./test/signed-profile.p7b"));
    options.emplace("signAlg", std::string("SHA256withECDSA"));
    options.emplace("keystorePwd", std::string("123456"));
    options.emplace("keystoreFile", std::string("./test/ohtest.jks"));
    options.emplace("appCertFile", std::string("./test/app-release1.pem"));
    options.emplace("inFile", std::string("./entry-default-unsigned-so.hap"));
    signerConfig.SetOptions(&options);

    CodeSigning codeSigning(signerConfig);

    std::string input = "libs/arm64-v8a/libc++_shared.so";
    bool flag = codeSigning.isNativeFile(input);

    EXPECT_EQ(flag, false);
}

/**
 * @tc.name: signFile
 * @tc.desc: Test function of SignToolServiceImpl::GenerateCsr() interface for SUCCESS.
 * @tc.size: MEDIUM
 * @tc.type: FUNC
 * @tc.level Level 1
 * @tc.require: SR000H63TL
 */
HWTEST_F(CodeSigningTest, signFile, testing::ext::TestSize.Level1)
{
    SignerConfig signerConfig;
    signerConfig.SetCompatibleVersion(9);

    std::map<std::string, std::string> params;
    params["keyPwd"] = "123456";
    params["mode"] = "localSign";
    params["keyAlias"] = "oh-app1-key-v1";
    params["signAlg"] = "SHA256withECDSA";
    params["appCertFile"] = "./test/app-release1.pem";
    params["signCode"] = "1";
    params["compatibleVersion"] = "9";
    params["outFile"] = "./entry-default-signed-so.hap";
    params["profileFile"] = "./test/signed-profile.p7b";
    params["keystorePwd"] = "123456";
    params["keystoreFile"] = "./test/ohtest.jks";
    params["inFile"] = "./entry-default-unsigned-so.hap";
    params["profileSigned"] = "1";
    signerConfig.FillParameters(params);

    ContentDigestAlgorithm contentDigestAlgorithm("SHA-256", 32);
    std::pair<std::string, void*> signatureAlgAndParams("SHA256withECDSA", nullptr);
    SignatureAlgorithmClass signatureAlgorithm(SignatureAlgorithmId::DSA_WITH_SHA256, "ECDSA_WITH_SHA256", contentDigestAlgorithm, signatureAlgAndParams);
    std::vector<SignatureAlgorithmClass> signatureAlgorithms;
    signatureAlgorithms.push_back(signatureAlgorithm);
    signerConfig.SetSignatureAlgorithms(signatureAlgorithms);

    Options options;
    options.emplace("mode", std::string("localSign"));
    options.emplace("keyPwd", std::string("123456"));
    options.emplace("outFile", std::string("./entry-default-signed-so.hap"));
    options.emplace("keyAlias", std::string("oh-app1-key-v1"));
    options.emplace("profileFile", std::string("./test/signed-profile.p7b"));
    options.emplace("signAlg", std::string("SHA256withECDSA"));
    options.emplace("keystorePwd", std::string("123456"));
    options.emplace("keystoreFile", std::string("./test/ohtest.jks"));
    options.emplace("appCertFile", std::string("./test/app-release1.pem"));
    options.emplace("inFile", std::string("./entry-default-unsigned-so.hap"));
    signerConfig.SetOptions(&options);

    CodeSigning codeSigning(signerConfig);
    
    std::ifstream inputStream;
    inputStream.open("entry-default-unsigned-so.hap", std::ios::binary);
    int64_t fileSize = 3479976;
    bool storeTree = true;
    int64_t fsvTreeOffset = 1024;
    std::string ownerID;
    std::pair<SignInfo, std::vector<int8_t>> ret;
    bool flag = codeSigning.signFile(inputStream, fileSize, storeTree, fsvTreeOffset, ownerID, ret);

    EXPECT_EQ(flag, false);
}

/**
 * @tc.name: SignFilesFromJar
 * @tc.desc: Test function of SignToolServiceImpl::GenerateCsr() interface for SUCCESS.
 * @tc.size: MEDIUM
 * @tc.type: FUNC
 * @tc.level Level 1
 * @tc.require: SR000H63TL
 */
HWTEST_F(CodeSigningTest, SignFilesFromJar, testing::ext::TestSize.Level1)
{
    SignerConfig signerConfig;
    signerConfig.SetCompatibleVersion(9);

    std::map<std::string, std::string> params;
    params["keyPwd"] = "123456";
    params["mode"] = "localSign";
    params["keyAlias"] = "oh-app1-key-v1";
    params["signAlg"] = "SHA256withECDSA";
    params["appCertFile"] = "./test/app-release1.pem";
    params["signCode"] = "1";
    params["compatibleVersion"] = "9";
    params["outFile"] = "./entry-default-signed-so.hap";
    params["profileFile"] = "./test/signed-profile.p7b";
    params["keystorePwd"] = "123456";
    params["keystoreFile"] = "./test/ohtest.jks";
    params["inFile"] = "./entry-default-unsigned-so.hap";
    params["profileSigned"] = "1";
    signerConfig.FillParameters(params);

    ContentDigestAlgorithm contentDigestAlgorithm("SHA-256", 32);
    std::pair<std::string, void*> signatureAlgAndParams("SHA256withECDSA", nullptr);
    SignatureAlgorithmClass signatureAlgorithm(SignatureAlgorithmId::DSA_WITH_SHA256, "ECDSA_WITH_SHA256", contentDigestAlgorithm, signatureAlgAndParams);
    std::vector<SignatureAlgorithmClass> signatureAlgorithms;
    signatureAlgorithms.push_back(signatureAlgorithm);
    signerConfig.SetSignatureAlgorithms(signatureAlgorithms);

    Options options;
    options.emplace("mode", std::string("localSign"));
    options.emplace("keyPwd", std::string("123456"));
    options.emplace("outFile", std::string("./entry-default-signed-so.hap"));
    options.emplace("keyAlias", std::string("oh-app1-key-v1"));
    options.emplace("profileFile", std::string("./test/signed-profile.p7b"));
    options.emplace("signAlg", std::string("SHA256withECDSA"));
    options.emplace("keystorePwd", std::string("123456"));
    options.emplace("keystoreFile", std::string("./test/ohtest.jks"));
    options.emplace("appCertFile", std::string("./test/app-release1.pem"));
    options.emplace("inFile", std::string("./entry-default-unsigned-so.hap"));
    signerConfig.SetOptions(&options);

    CodeSigning codeSigning(signerConfig);

    std::vector<std::tuple<std::string, std::stringbuf, uLong>> entryNames;
    std::string packageName = "libs/arm64-v8a/libc++_shared.so";
    std::string ownerID;
    std::vector<std::pair<std::string, SignInfo>> ret;
    bool flag = codeSigning.SignFilesFromJar(entryNames, packageName, ownerID, ret);

    EXPECT_EQ(flag, false);
}

/**
 * @tc.name: signNativeLibs
 * @tc.desc: Test function of SignToolServiceImpl::GenerateCsr() interface for SUCCESS.
 * @tc.size: MEDIUM
 * @tc.type: FUNC
 * @tc.level Level 1
 * @tc.require: SR000H63TL
 */
HWTEST_F(CodeSigningTest, signNativeLibs, testing::ext::TestSize.Level1)
{
    SignerConfig signerConfig;
    signerConfig.SetCompatibleVersion(9);

    std::map<std::string, std::string> params;
    params["keyPwd"] = "123456";
    params["mode"] = "localSign";
    params["keyAlias"] = "oh-app1-key-v1";
    params["signAlg"] = "SHA256withECDSA";
    params["appCertFile"] = "./test/app-release1.pem";
    params["signCode"] = "1";
    params["compatibleVersion"] = "9";
    params["outFile"] = "./entry-default-signed-so.hap";
    params["profileFile"] = "./test/signed-profile.p7b";
    params["keystorePwd"] = "123456";
    params["keystoreFile"] = "./test/ohtest.jks";
    params["inFile"] = "./entry-default-unsigned-so.hap";
    params["profileSigned"] = "1";
    signerConfig.FillParameters(params);

    ContentDigestAlgorithm contentDigestAlgorithm("SHA-256", 32);
    std::pair<std::string, void*> signatureAlgAndParams("SHA256withECDSA", nullptr);
    SignatureAlgorithmClass signatureAlgorithm(SignatureAlgorithmId::DSA_WITH_SHA256, "ECDSA_WITH_SHA256", contentDigestAlgorithm, signatureAlgAndParams);
    std::vector<SignatureAlgorithmClass> signatureAlgorithms;
    signatureAlgorithms.push_back(signatureAlgorithm);
    signerConfig.SetSignatureAlgorithms(signatureAlgorithms);

    Options options;
    options.emplace("mode", std::string("localSign"));
    options.emplace("keyPwd", std::string("123456"));
    options.emplace("outFile", std::string("./entry-default-signed-so.hap"));
    options.emplace("keyAlias", std::string("oh-app1-key-v1"));
    options.emplace("profileFile", std::string("./test/signed-profile.p7b"));
    options.emplace("signAlg", std::string("SHA256withECDSA"));
    options.emplace("keystorePwd", std::string("123456"));
    options.emplace("keystoreFile", std::string("./test/ohtest.jks"));
    options.emplace("appCertFile", std::string("./test/app-release1.pem"));
    options.emplace("inFile", std::string("./entry-default-unsigned-so.hap"));
    signerConfig.SetOptions(&options);

    CodeSigning codeSigning(signerConfig);
    
    std::string input = "entry-default-signed-so.hap";
    std::string ownerID;
    bool flag = codeSigning.signNativeLibs(input, ownerID);

    EXPECT_EQ(flag, false);
}

/**
 * @tc.name: splitFileName
 * @tc.desc: Test function of SignToolServiceImpl::GenerateCsr() interface for SUCCESS.
 * @tc.size: MEDIUM
 * @tc.type: FUNC
 * @tc.level Level 1
 * @tc.require: SR000H63TL
 */
HWTEST_F(CodeSigningTest, splitFileName, testing::ext::TestSize.Level1)
{
    SignerConfig signerConfig;
    signerConfig.SetCompatibleVersion(9);

    std::map<std::string, std::string> params;
    params["keyPwd"] = "123456";
    params["mode"] = "localSign";
    params["keyAlias"] = "oh-app1-key-v1";
    params["signAlg"] = "SHA256withECDSA";
    params["appCertFile"] = "./test/app-release1.pem";
    params["signCode"] = "1";
    params["compatibleVersion"] = "9";
    params["outFile"] = "./entry-default-signed-so.hap";
    params["profileFile"] = "./test/signed-profile.p7b";
    params["keystorePwd"] = "123456";
    params["keystoreFile"] = "./test/ohtest.jks";
    params["inFile"] = "./entry-default-unsigned-so.hap";
    params["profileSigned"] = "1";
    signerConfig.FillParameters(params);

    ContentDigestAlgorithm contentDigestAlgorithm("SHA-256", 32);
    std::pair<std::string, void*> signatureAlgAndParams("SHA256withECDSA", nullptr);
    SignatureAlgorithmClass signatureAlgorithm(SignatureAlgorithmId::DSA_WITH_SHA256, "ECDSA_WITH_SHA256", contentDigestAlgorithm, signatureAlgAndParams);
    std::vector<SignatureAlgorithmClass> signatureAlgorithms;
    signatureAlgorithms.push_back(signatureAlgorithm);
    signerConfig.SetSignatureAlgorithms(signatureAlgorithms);

    Options options;
    options.emplace("mode", std::string("localSign"));
    options.emplace("keyPwd", std::string("123456"));
    options.emplace("outFile", std::string("./entry-default-signed-so.hap"));
    options.emplace("keyAlias", std::string("oh-app1-key-v1"));
    options.emplace("profileFile", std::string("./test/signed-profile.p7b"));
    options.emplace("signAlg", std::string("SHA256withECDSA"));
    options.emplace("keystorePwd", std::string("123456"));
    options.emplace("keystoreFile", std::string("./test/ohtest.jks"));
    options.emplace("appCertFile", std::string("./test/app-release1.pem"));
    options.emplace("inFile", std::string("./entry-default-unsigned-so.hap"));
    signerConfig.SetOptions(&options);

    CodeSigning codeSigning(signerConfig);
    
    std::string path = "libs/arm64-v8a/libc++_shared.so";
    std::string str = codeSigning.splitFileName(path);

    EXPECT_EQ(str.size(), 0);
}

/**
 * @tc.name: updateCodeSignBlock
 * @tc.desc: Test function of SignToolServiceImpl::GenerateCsr() interface for SUCCESS.
 * @tc.size: MEDIUM
 * @tc.type: FUNC
 * @tc.level Level 1
 * @tc.require: SR000H63TL
 */
HWTEST_F(CodeSigningTest, updateCodeSignBlock, testing::ext::TestSize.Level1)
{
    SignerConfig signerConfig;
    signerConfig.SetCompatibleVersion(9);

    std::map<std::string, std::string> params;
    params["keyPwd"] = "123456";
    params["mode"] = "localSign";
    params["keyAlias"] = "oh-app1-key-v1";
    params["signAlg"] = "SHA256withECDSA";
    params["appCertFile"] = "./test/app-release1.pem";
    params["signCode"] = "1";
    params["compatibleVersion"] = "9";
    params["outFile"] = "./entry-default-signed-so.hap";
    params["profileFile"] = "./test/signed-profile.p7b";
    params["keystorePwd"] = "123456";
    params["keystoreFile"] = "./test/ohtest.jks";
    params["inFile"] = "./entry-default-unsigned-so.hap";
    params["profileSigned"] = "1";
    signerConfig.FillParameters(params);

    ContentDigestAlgorithm contentDigestAlgorithm("SHA-256", 32);
    std::pair<std::string, void*> signatureAlgAndParams("SHA256withECDSA", nullptr);
    SignatureAlgorithmClass signatureAlgorithm(SignatureAlgorithmId::DSA_WITH_SHA256, "ECDSA_WITH_SHA256", contentDigestAlgorithm, signatureAlgAndParams);
    std::vector<SignatureAlgorithmClass> signatureAlgorithms;
    signatureAlgorithms.push_back(signatureAlgorithm);
    signerConfig.SetSignatureAlgorithms(signatureAlgorithms);

    Options options;
    options.emplace("mode", std::string("localSign"));
    options.emplace("keyPwd", std::string("123456"));
    options.emplace("outFile", std::string("./entry-default-signed-so.hap"));
    options.emplace("keyAlias", std::string("oh-app1-key-v1"));
    options.emplace("profileFile", std::string("./test/signed-profile.p7b"));
    options.emplace("signAlg", std::string("SHA256withECDSA"));
    options.emplace("keystorePwd", std::string("123456"));
    options.emplace("keystoreFile", std::string("./test/ohtest.jks"));
    options.emplace("appCertFile", std::string("./test/app-release1.pem"));
    options.emplace("inFile", std::string("./entry-default-unsigned-so.hap"));
    signerConfig.SetOptions(&options);

    CodeSigning codeSigning(signerConfig);

    codeSigning.updateCodeSignBlock();

    EXPECT_EQ(true, 1);
}
